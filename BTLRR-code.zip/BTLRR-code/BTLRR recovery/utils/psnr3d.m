function [psnr]  =  psnr3d(imagery1,imagery2)
psnr = 0;
for i = 1:size(imagery1,3)
    psnr = psnr + 10*log10(255^2/mse(imagery1(:, :, i) - imagery2(:, :, i)));
end
psnr = psnr/size(imagery1,3);
end