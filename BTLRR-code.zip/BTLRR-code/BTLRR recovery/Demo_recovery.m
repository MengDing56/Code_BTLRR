clc; clear; close all;
addpath(genpath(cd));
% rng('default');
%% step 1 read data and process data 
load toy.mat
X0 = toy; % 0-1

[n1, n2, n3] = size(X0);

%% add noise   
NR = 0.2;
Omega = find(rand(n1*n2*n3,1)<NR);
X = X0;
X(Omega) = randi([0,255],length(Omega),1)./255.0;
    
opts.lambda = 1/sqrt(max(n1,n2)*n3);
opts.mu = 1e-4;
opts.tol = 1e-8;
opts.rho = 1.2;
opts.max_iter = 800;
opts.DEBUG = 0;
% construct the dictionary
[L, E, rank] = dictionary_learning(X, opts);
   
% approximate L
[L_hat, trank, U, V, S] = prox_low_rank(L, 50);
LL = tprod(U, S);
RR = tprod(S, tran(V));
    
lam = 3;
mu = 0.001;
lambda = lam/(sqrt(n3*max(n1, n2)));
        
[Z, L1, E, out] = BTLRR(X, LL, RR, lambda, mu);
L = tprod(LL, Z) + tprod(L1, RR);
        
X    = min(255, max(L, 0));
psnr = psnr3d(X*255, X0*255);
ssim = ssim3d(X*255, X0*255);
    
display(sprintf('lam = %.3f, mu = %.5f, psnr = %.2f, ssim = %.4f', lam, mu, psnr, ssim))
display(sprintf('=================================='))
    