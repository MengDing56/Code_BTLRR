function [ inv_a ] = t_inverse(A)

[~,n4,n3]=size(A);

A = fft(A,[],3);
inv_a = zeros(n4,n4,n3);
for i = 1 : n3
   inv_a(:,:,i) =  (A(:,:,i)'*A(:,:,i) + eye(n4))\eye(n4);
end
% inv_a = (Abar'*Abar + eye(m*d2))\eye(m*d2);
inv_a = ifft(inv_a,[],3);

end

