clc; clear; close all;
addpath(genpath(cd));
% rng('default');
%% step 1 read data and process data 
load extendyaleb.mat
X0 = X/255.0;

[n1, n2, n3] = size(X0);
X  = X0;

NR = 0.1; % sparse noise level
    
Omega    = find(rand(n1*n2*n3, 1) < NR);
X(Omega) = randi([0,255], length(Omega), 1)./255.0;
 
opts.denoising_flag = 1; 
% (1 denotes we use R-TPCA; 0 deonotes we do not use)
if opts.denoising_flag
    [n1, n2, n3] = size(X);
    opts.lambda = 1/sqrt(max(n1,n2)*n3);
    opts.mu = 1e-4;
    opts.tol = 1e-4;
    opts.rho = 1.2;
    opts.max_iter = 800;
    opts.DEBUG = 0; 
end    
[LL, V, U, RR] = dictionary_learning2(X, opts);
      
lam = 0.9;
   mu = 0.1;
   lambda = lam/(sqrt(n3*max(n1, n2)));
   [Z, L, E, out] = BTLRR(X, LL, RR, lambda, mu);
   Z = tprod(V, Z);
   L = tprod(L, tran(U));
        
   t = 2;
   mean_nmi = ncut_clustering(Z, label', t);

   display(sprintf('ACC = %.4f, NMI = %.4f, PUR = %.4f', mean_nmi(1), mean_nmi(2), mean_nmi(3)))
   display(sprintf('=================================='))

    